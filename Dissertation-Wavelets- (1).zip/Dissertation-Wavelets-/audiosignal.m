% Load the audio signal
[audio, fs] = audioread('speech_dft.wav');

% Ensure mono signal
if size(audio, 2) > 1
audio = mean(audio, 2);
end

% Ensure even number of samples
if mod(length(audio), 2) ~= 0
audio = audio(1:end-1); % Remove the last sample
end

% Perform Haar Wavelet Transform
[a, d] = haart(audio, 'integer');

% Reconstruct Haar approximation at a specific level (e.g., 5)
HaarAudio = ihaart(a, d, 5, 'integer');

% Create time vectors
time = (0:length(audio)-1)/fs;

% Plot the original and Haar-approximated signals
figure;
subplot(2, 1, 1);
plot(time, audio);
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0,0.2]);
title('Original Audio Signal');
grid on;

subplot(2, 1, 2);
plot(time, HaarAudio, 'b', 'LineWidth', 1);
xlabel('Time (s)');
ylabel('Amplitude');
xlim([0,0.2]);
title('Haar Approximation of Audio Signal');
grid on;

