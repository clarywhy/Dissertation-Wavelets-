img = imread('cameraman.tif');  % Load the built-in image
row_intensity = double(img(100, :));  % Extract and convert the 100th row to double
plot(row_intensity);
xlabel('Pixel Position');
ylabel('Intensity');
xlim([0,256])
title('Intensity Profile of Cameraman Image (100th row)');



% Create a copy of the image for visualization
img_marked = img;

% Convert grayscale image to RGB
if size(img, 3) == 1
    img_rgb = cat(3, img, img, img);
else
    img_rgb = img;
end

% Define the row to mark
row_to_mark = 100;

% Mark the row with a red line by setting the red channel to 255 and the others to 0
img_rgb(row_to_mark, :, 1) = 255;  % Red channel: set to maximum
img_rgb(row_to_mark, :, 2) = 0;    % Green channel: set to 0
img_rgb(row_to_mark, :, 3) = 0;    % Blue channel: set to 0

% Display the marked image
figure;
imshow(img_rgb);
title('Cameraman Image with Marked Row');

img = imread('cameraman.tif');
row_range = 50:150; % Select multiple rows
signal_2D = double(img(row_range, :)); % Extract region as a 2D matrix
figure;
imagesc(signal_2D);
colormap gray;
xlabel('Pixel Index');
ylabel('Row Index');
title('2D Signal Extracted from Image');
colorbar;