% Load the audio signal
[audio, fs] = audioread('speech_dft.wav'); % Replace 'speech_dft.wav' with your audio file path

% Ensure mono signal (if it's stereo, take the mean of the channels)
if size(audio, 2) > 1
    audio = mean(audio, 2);
end

% Ensure even number of samples (Haar transform works best with even lengths)
if mod(length(audio), 2) ~= 0
    audio = audio(1:end-1); % Remove the last sample if the length is odd
end

% Perform Haar Wavelet Transform
[a, d] = haart(audio, 'integer');

% Define levels (finest to coarsest - same as before)
selected_levels = num_levels:-1:1;

% Create figure and tiled layout
figure;
tiledlayout(num_levels + 1, 1, 'TileSpacing', 'none', 'Padding', 'none');

% Plot Haar approximations (finest to coarsest)
for idx = 1:num_levels
    j = selected_levels(idx);
    nexttile;

    HaarApprox = ihaart(a, d, j, 'integer');
    plot(time, HaarApprox, 'b', 'LineWidth', 1);

    % Correct y-axis label (reversed order)
    ylabel(['j = ', num2str(num_levels - j + 1)], 'FontSize', 10, 'FontWeight', 'bold'); % Reversed j

    xlim([0, 0.2]);
    grid on;

    % Remove x-axis labels (only for subplots above the last one)
    if idx < num_levels
        set(gca, 'XTickLabel', []);
    end

    % Remove y-axis numbers
    set(gca, 'YTickLabel', []); % Remove y-axis numbers
end

% Plot original signal (at the top)
nexttile;
plot(time, audio, 'k', 'LineWidth', 1);
ylabel('Original', 'FontSize', 10, 'FontWeight', 'bold');
xlabel('Time (s)');
xlim([0, 0.2]);
grid on;
set(gca, 'YTickLabel', []); % Remove y-axis numbers for original signal plot too


% ... (Optional: Overall title and figure appearance improvements)

print('Haar_MRA_Figure', '-dpdf', '-r300');  % Save as PDF, 300 dpi