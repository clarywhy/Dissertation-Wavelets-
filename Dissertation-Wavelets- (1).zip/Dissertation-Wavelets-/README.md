The practical component of my dissertation project, which aims to use the CLEAR algorithm and other methods developed by [1] to mitigate atmospheric turblence in images and video using wavelet based methods


[1] Anantrasirichai, N.; Achim, A.; Kingsbury, N.G.; Bull, D.R., "Atmospheric
Turbulence Mitigation Using Complex Wavelet-Based Fusion," Image Processing,
IEEE Transactions on , vol.22, no.6, pp.2398-2408, June 2013
