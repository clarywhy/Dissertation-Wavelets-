% Load the audio signal
[audio, fs] = audioread('speech_dft.wav');

% Ensure mono signal
if size(audio, 2) > 1
    audio = mean(audio, 2);
end

% Create time vector
time = (0:length(audio)-1) / fs;

% Perform MODWT (Maximal Overlap Discrete Wavelet Transform)
wname = 'db4';  % Daubechies-4 wavelet
level = 8;  % Decomposition levels
W = modwt(audio, level, wname);  % Compute MODWT coefficients

% Compute Multiresolution Analysis (MRA) using MODWT coefficients
mra_coeff = modwtmra(W, wname);

% Set plot title
titlestr = 'Wavelet Multiresolution Analysis (MODWT)';

% Specify highlighted levels (optional)
highlight_levels = [2 3 4 9];  % Highlight certain levels in the plot

% Call `helperMRAPlot` to visualize the decomposition
helperMRAPlot(audio, mra_coeff, time, "wavelet", titlestr, highlight_levels);