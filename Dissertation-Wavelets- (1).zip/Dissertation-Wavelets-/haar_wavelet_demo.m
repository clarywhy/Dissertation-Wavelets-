x = linspace(-10, 10, 1000); % Broad range to suggest infinite oscillations
y = sin(10*x); % Simple sine wave

figure;
plot(x, y, 'b', 'LineWidth', 1);
title('Infinitely Oscillating Wave');
xlabel('x');
ylabel('Amplitude');
ylim([-2,2])
grid on;

% Plot a high-frequency infinitely oscillating sine wave
x = linspace(-10, 10, 1000); % Broad range
y = sin(10 * x); % Increased frequency

figure;
plot(x, y, 'b', 'LineWidth', 1);
title('Sine Wave');
xlabel('x');
ylabel('Amplitude');
ylim([-2, 2]); % Increased y-axis limits
grid on;

% Define parameters for Morlet wavelet
x = linspace(-10, 10, 1000); % Time axis
f = 1; % Frequency parameter
sigma = 1; % Standard deviation of Gaussian envelope

% Compute Morlet wavelet
wavelet = cos(2 * pi * f * x) .* exp(-x.^2 / (2 * sigma^2));

% Plot Morlet wavelet
figure;
plot(x, wavelet, 'b', 'LineWidth', 1);
title('Wavelet');
xlabel('x');
ylabel('Amplitude');
ylim([-2,2])
grid on;



% Define x-axis range
x = linspace(-1, 2, 1000); % Extend beyond x=1

% Haar Scaling Function (Father Wavelet φ)
phi = double(x >= 0 & x < 1); % 1 for 0 ≤ x < 1, 0 otherwise

% Extend the value at x=0 for x > 1
phi(x > 1) = phi(1); % Set all x > 1 to φ(0) which is 1

% Plot Haar Scaling Function
figure;
plot(x, phi, 'b', 'LineWidth', 2);
xlabel('Time (t)');
ylabel('Amplitude');
xlim([-1, 2]); % Adjust x-axis limits
ylim([-0.2, 1.2]); % Adjust y-axis limits
title('Haar Scaling Function (Father Wavelet)');
grid on;


% Haar Wavelet Function (Mother Wavelet ψ)
psi = double((x >= 0 & x < 0.5) - (x >= 0.5 & x < 1));

% Extend value at x=0 for x > 1
psi(x >= 1) = psi(1); % Extend ψ(0) for x > 1

% Plot Haar Wavelet Function
figure;
plot(x, psi, 'r', 'LineWidth', 2);
xlabel('Time (t)');
ylabel('Amplitude');
xlim([-1, 2]); % Adjust x-axis limits
ylim([-1.2, 1.2]); % Adjust y-axis limits
title('Haar Wavelet Function (Mother Wavelet)');
grid on;