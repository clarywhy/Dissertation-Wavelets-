% Read and preprocess image
I = imread('cameraman.tif');
I = im2double(I);

% Perform 1-level DWT
[LL, LH, HL, HH] = dwt2(I, 'db1');  % or any wavelet like 'haar'

% Sum the detail subbands to create an overlay
overlay = LH + HL + HH;

% Optionally normalise for display
overlay = overlay - min(overlay(:));
overlay = overlay / max(overlay(:));

% Display the overlay
figure;
imshow(overlay, []);
title('Overlay of LH, HL, HH DWT Subbands');

print(gcf, 'dwt_subbandsoverlay.png', '-dpdf', '-bestfit');