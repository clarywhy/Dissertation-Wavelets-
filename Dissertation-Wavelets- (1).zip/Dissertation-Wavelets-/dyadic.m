% Haar Wavelet Transform in MATLAB

function haar_wavelet_demo()
    % Example usage
    data = [5, 8, 6, 3, 4, 7, 9, 1]; % Input signal
    disp('Original Signal:');
    disp(data);

    % Perform forward Haar Wavelet Transform
    [approx, detail] = haar_wavelet_transform(data);
    disp('Approximation Coefficients:');
    disp(approx);
    disp('Detail Coefficients:');
    disp(detail);

    % Reconstruct the signal using inverse Haar Wavelet Transform
    reconstructed = inverse_haar_wavelet_transform(approx, detail);
    disp('Reconstructed Signal:');
    disp(reconstructed);

    % Illustrate wavelet vs infinitely oscillating wave (Fourier transform)
    illustrate_wavelet_vs_fourier();
    
    % Illustrate dyadic scaling on Haar wavelet with MRA
    illustrate_mra_haar_wavelet();
end

% Forward Haar Wavelet Transform
function [approx, detail] = haar_wavelet_transform(data)
    n = length(data);
    if mod(n, 2) ~= 0
        error('Input length must be even.');
    end

    approx = zeros(1, n/2);
    detail = zeros(1, n/2);

    for i = 1:2:n
        approx((i+1)/2) = (data(i) + data(i+1)) / sqrt(2); % Average
        detail((i+1)/2) = (data(i) - data(i+1)) / sqrt(2); % Difference
    end
end

% Inverse Haar Wavelet Transform
function reconstructed = inverse_haar_wavelet_transform(approx, detail)
    n = length(approx) + length(detail);
    reconstructed = zeros(1, n);

    for i = 1:length(approx)
        reconstructed(2*i-1) = (approx(i) + detail(i)) / sqrt(2); % Reconstruct odd index
        reconstructed(2*i) = (approx(i) - detail(i)) / sqrt(2); % Reconstruct even index
    end
end

% Illustrate Wavelet vs Infinitely Oscillating Wave
function illustrate_wavelet_vs_fourier()
    x = linspace(-2*pi, 2*pi, 1000); % Reduced x-axis limits

    % Wavelet example (Haar wavelet)
    wavelet = zeros(size(x));
    wavelet(x >= -pi & x < 0) = 1; % Positive half
    wavelet(x >= 0 & x < pi) = -1; % Negative half

    % Infinitely oscillating wave (Fourier sine wave)
    sine_wave = sin(x);

    % Plot Wavelet
    figure;
    plot(x, wavelet, 'b', 'LineWidth', 1);
    title('Haar Wavelet');
    xlabel('x');
    ylabel('Amplitude');
    grid on;

    % Plot Fourier sine wave
    figure;
    plot(x, sine_wave, 'r', 'LineWidth', 1);
    title('Infinitely Oscillating Wave (Fourier)');
    xlabel('x');
    ylabel('Amplitude');
    grid on;
end

% Illustrate MRA using Haar Wavelet
function illustrate_mra_haar_wavelet()
    scales = [1, 2, 4, 8]; % Dyadic scales for MRA
    x = linspace(-1, 1, 1000);
    figure;
    
    for i = 1:length(scales)
        j = log2(scales(i)); % Scale factor exponent
        wavelet = sqrt(2^j) * ((x >= 0 & x < 1/(2^j)) - (x >= 1/(2^j) & x < 2/(2^j)));
        
        subplot(length(scales), 1, i);
        plot(x, wavelet, 'b', 'LineWidth', 1);
        title(['Haar Wavelet MRA at Scale 2^', num2str(j)]);
        xlabel('t');
        ylabel('ψ_{j}(t)');
        ylim([-2, 2]);
        xlim([-1, 1]);
        grid on;
    end
    sgtitle('Multiresolution Analysis (MRA) using Haar Wavelet');
end
