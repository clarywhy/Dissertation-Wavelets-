% Load the audio signal
[audio, fs] = audioread('speech_dft.wav'); % Replace 'speech_dft.wav' with your audio file path

% Ensure mono signal
if size(audio, 2) > 1
    audio = mean(audio, 2);
end

% Ensure even number of samples
if mod(length(audio), 2) ~= 0
    audio = audio(1:end-1);
end

% Perform Haar Wavelet Transform
[a, d] = haart(audio, 'integer');

% Define the levels to visualize (SPECIFIC LEVELS)
selected_levels = [1, 4, 7, 10, 12];

% Create time vector
time = (0:length(audio)-1) / fs;

% Create figure and tiled layout
figure;
num_levels_to_display = length(selected_levels); % Number of plots
tiledlayout(num_levels_to_display + 1, 1, 'TileSpacing', 'none', 'Padding', 'none');

% Plot original signal (at the VERY TOP)
nexttile;
plot(time, audio, 'k', 'LineWidth', 1);
ylabel('Original', 'FontSize', 10, 'FontWeight', 'bold');
xlabel('Time (s)');
xlim([0, 0.2]);
grid on;
set(gca, 'YTickLabel', []);


% Plot Haar approximations (in the SAME order as before)
for idx = 1:num_levels_to_display
    j = selected_levels(idx);
    nexttile;

    HaarApprox = ihaart(a, d, j, 'integer'); 

    plot(time, HaarApprox, 'b', 'LineWidth', 1);

    % Reversed j label for plotting order from 1 at bottom to 12 at top
    reversed_j = selected_levels(num_levels_to_display - idx + 1);  % Reverse the index
    ylabel(['j = ', num2str(reversed_j)], 'FontSize', 10, 'FontWeight', 'bold'); 

    xlim([0, 0.2]);
    grid on;

    % Remove x-axis labels (except for the bottom plot)
    if idx < num_levels_to_display
        set(gca, 'XTickLabel', []);
    end

    % Remove y-axis numbers
    set(gca, 'YTickLabel', []);
end



% Save the figure (optional - adjust path and filename)
outputPath = '/Users/clarissahui/Desktop/Uni/Dissertation/Figures'; % Replace with your desired path
filename = fullfile(outputPath, 'Haar_MRA_Figure_SpecificLevels.pdf'); 
print(filename, '-dpdf', '-r300');
